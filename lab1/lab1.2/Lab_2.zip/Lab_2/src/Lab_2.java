import java.util.Scanner;

public class Lab_2 {
    public static void main(String[] args) {
        int i;
        final int STEP = 2;
        final int DIVISOR_TWO = 2;
        long number = 0;
        long nMax = 0;
        final int MIN = 1;
        final int MAX = 50;
        long nFactFact = 1;
        boolean isInCorrect = true;
        Scanner scan = new Scanner(System.in);

        System.out.printf("Данная программа принимает n, и считает 1*3*...*n " +
                          "для нечетного n и 2* 4*...*n для четного n.\n");
        System.out.printf("Введите n (n - натуральное число)\n");
        System.out.printf("Диапазон значений n : %d....%d\n", MIN, MAX);

        do {
            try {
                number = Long.parseLong(scan.nextLine());

                if (number < MIN || number > MAX) {
                    System.err.printf("Повторите ввод. Диапазон значений n : %d....%d\n", MIN, MAX);
                    isInCorrect = true;
                } else {
                    isInCorrect = false;
                }
            } catch (NumberFormatException ex) {
                if (ex.getMessage() != null) System.err.print("Некорректный ввод!");
                System.err.println("Повторите попытку");
            }
        } while (isInCorrect);

        scan.close();

        nMax = number + 1;

        if (number % DIVISOR_TWO == 1) {
            for (i = 1; i < nMax; i += STEP) {
                nFactFact *= i;
            }
        } else {
            for (i = 2; i < nMax; i += STEP) {
                nFactFact *= i;
            }
        }

        System.out.println("n!! =  " + nFactFact);
    }
}